#### APARTMENT PRICE PROJECT CODE

### MULTIPLE LINEAR REGRESSION

rm(list = ls())


library("tidyverse")

library("rpart")

library("rpart.plot")

library("caret")

library("forecast")


#### multiple linear regression on the Apartment data ####

#Filter out values where price = 0

apartments = read_csv("Equity_Apartments_Data.csv")

apartments = apartments %>%
  filter(Price != 0)

#Will work on all observations and the following variables
#Beds, Baths, sq.ft, Floor, City, Balcony, Walk_In_Closet, Fireplace, City_Skyline,  Kitchen_Island, Stainless_Appliances, Renovated, Office_Space
#Price is the output variable and the remaining are predictors/input variables

apartments  = apartments %>%
  select(Price, Beds, Baths, sq.ft, Floor, City, Balcony, Walk_In_Closet, Fireplace, City_Skyline, Kitchen_Island, Stainless_Appliances, Renovated, Office_Space)

# multiple linear regression model

apartments.mlr = lm(Price ~ Beds + Baths + sq.ft + Floor + City + Balcony + Walk_In_Closet + Fireplace + Kitchen_Island + City_Skyline + Stainless_Appliances + Renovated + Office_Space, apartments)

# summary of the multiple linear regression model

summary(apartments.mlr)
# R-Squared = 0.6704

### Accuracy/Error Measures ###

rm(list = ls())


apartments = read_csv("Equity_Apartments_Data.csv")

apartments = apartments %>%
  filter(Price != 0)

apartments  = apartments %>%
  select(Price, Beds, Baths, sq.ft, Floor, City, Balcony, Walk_In_Closet, Fireplace, City_Skyline, Kitchen_Island, Stainless_Appliances, Renovated, Office_Space)

##### evaluate predictive performance of the multiple linear regression ####

apartments  = apartments %>%
  mutate(id = 1:nrow(apartments))

apartments  = apartments %>%
  rename(Price_actual = Price)

# data partition - train & validation

set.seed(30)

train = apartments %>%
  sample_frac(0.7)

validation = apartments %>%
  slice(setdiff(apartments$id, train$id))

train.mlr = lm(Price_actual ~ Beds + Baths + sq.ft + Floor + City + Balcony + Walk_In_Closet + Fireplace + Kitchen_Island  + City_Skyline + Stainless_Appliances + Renovated + Office_Space, train)

summary(train.mlr)
# R-Squared = 0.672

#### error/accuracy measures ####

#### validation data ####

validation = validation %>%
  mutate(Price_prediction = predict(train.mlr, validation))

accuracy(validation$Price_prediction, validation$Price_actual)

#ME : 5.036651    RMSE: 600.3999  MAE: 429.0811  MPE: -2.308726  MAPE: 13.82798

#### train data ####

train = train %>%
  mutate(Price_prediction = predict(train.mlr, train))

accuracy(train$Price_prediction, train$Price_actual)

# ME: -2.480351e-10, RMSE: 587.9017, MAE: 422.9525 MPE: -2.422915, MAPE: 13.75392





### REGRESSION TREE

rm(list = ls())

apartments = read_csv("Equity_Apartments_Data.csv")

# view(head(apartments))

# remove all entries where price = 0
apartments = subset(apartments, Price > 0)

# Predictors: Beds, Baths, sq.ft, Floor, City, Balcony, Walk_In_Closet, Fireplace, City_Skyline,  Kitchen_Island, Stainless_Appliances, Renovated, Office_Space
# Target: Price
apartments  = apartments %>%
  rename(Price_Actual = Price) %>%
  select(Price_Actual, Beds, Baths, sq.ft, Floor, City, Balcony, Walk_In_Closet, 
         Fireplace, City_Skyline, Kitchen_Island, Stainless_Appliances, Renovated, Office_Space)

# create a new variable "id" that reflects the row number
apartments = apartments %>%
  mutate(id = 1:nrow(apartments))


## data partition - train & validation
set.seed(30)

train = apartments %>%
  sample_frac(0.7)

validation = apartments %>%
  slice(setdiff(apartments$id, train$id))


## run Regression Tree
apartments.rt = rpart(Price_Actual ~ Beds + Baths + sq.ft + Floor + City +
                        Balcony + Walk_In_Closet + Fireplace + City_Skyline + Kitchen_Island + 
                        Stainless_Appliances + Renovated + Office_Space, 
                      data = train, method = "anova",
                      cp = 0.005, minsplit = 10, xval = 10)

## plot + find where rel error val stabilizes without risk of overfit
plotcp(apartments.rt)

## find n-split val + its cp val
cp.table = as_tibble(apartments.rt$cptable)

## view(cp.table)

optimal.cp = cp.table %>%
  filter(nsplit == 20)

## prune tree with "optimal.cp" val
pruned.ct = prune(apartments.rt, cp = optimal.cp$CP)

## plot pruned tree
prp(pruned.ct, type = 1, extra = 1, under = TRUE, split.font = 2, varlen = -10)

## predict price for validation & train
prediction_v = predict(pruned.ct, validation, type = "vector")
prediction_t = predict(pruned.ct, train, type = "vector")


## GENERATE ACCURACY MEASURES

# FOR VALIDATION SET
validation = validation %>%
  mutate(price_prediction = prediction_v)

accuracy(validation$price_prediction, validation$Price_Actual)
## ME: 3.090935, RMSE: 592.331, MAE: 424.6689, MPE: -2.972066, MAPE: 14.03407



# FOR TRAIN SET
train = train %>%
  mutate(price_prediction = prediction_t)

accuracy(train$price_prediction, train$Price_Actual)
## ME: -2.206727e-15, RMSE: 578.8034, MAE: 416.8932, MPE: -2.994612, MAPE: 13.86549



## R2 Value Calc

a=sum((validation$Price_Actual-validation$price_prediction)^2)           
b=sum((validation$Price_Actual-mean(validation$Price_Actual))^2)
R_Squared = 1-(a/b)
print(R_Squared)

## R2 Val = 0.6706